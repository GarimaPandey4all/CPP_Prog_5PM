#include <iostream>

using namespace std;

class Shape
{
public:
    void shape()
    {
        cout<<"Shape"<<endl;
    }
};

class Circle : public Shape
{
public:
    void shape()
    {
        cout<<"Shape Circle"<<endl;
    }
};

int main()
{
    Circle obj;
    obj.shape();

    return 0;
}
