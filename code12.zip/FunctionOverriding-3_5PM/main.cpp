#include <iostream>

using namespace std;

class Shape
{
public:
    virtual void shape()
    {
        cout<<"Shape"<<endl;
    }
};

class Circle : public Shape
{
public:
    void shape()
    {
        cout<<"Shape Circle"<<endl;
    }
};

int main()
{
    Shape *bptr;
    Shape obj1;
    Circle obj;


    //bptr = &obj1;
    bptr = &obj;

    //Virtual Function, bind at runtime
    bptr->shape();

    return 0;
}
