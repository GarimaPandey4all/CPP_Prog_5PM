#include <iostream>

using namespace std;

//Abstract Class
class Shape
{
public:
    virtual void shape() = 0; //Pure Virtual Function
};

class Circle : public Shape
{
public:
    void shape()
    {
        cout<<"Shape Circle"<<endl;
    }
};

class Square : public Shape
{
public:
    void shape()
    {
        cout<<"Shape Square"<<endl;
    }
};

int main()
{
    Circle obj;
    obj.shape();

    Square obj1;
    obj1.shape();

    return 0;
}
