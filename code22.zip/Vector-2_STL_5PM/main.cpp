#include <iostream>
#include <vector>

using namespace std;

int main()
{
    vector <int> v1;
    vector <char> v2(4);
    vector <int> v3(5, 10);// size = 5, 10 is value to all the five locations
    vector <string> v4(4, "Hi");

    //Subscript Operator

    cout<<v4[0]<<endl;
    cout<<v4[1]<<endl;
    cout<<v4[2]<<endl;
    cout<<v4[3]<<endl;

    //at(), front(), back()

    cout<<"At():"<<v3.at(2)<<endl;
    cout<<"front():"<<v2.front()<<endl;
    cout<<"back():"<<v3.back()<<endl;

    return 0;
}
