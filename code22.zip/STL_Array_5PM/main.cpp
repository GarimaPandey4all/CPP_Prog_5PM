#include <iostream>
#include <array>

using namespace std;

int main()
{
    //Array is a linear collection of similar elements.
    //Array Container in STL provides us the implementation of static array.

    array<int, 5> data_array = {10, 20, 30, 40, 50}; //Declaration and Initialization
    array<int, 5> data_array1 = {1, 2, 3, 4, 5};

    //at()

    cout<<"Value is:"<<data_array.at(2)<<endl;

    //[]operator

    cout<<"Value is:"<<data_array[4]<<endl;

    //front()

    cout<<"Value is:"<<data_array.front()<<endl;

    //back()

    cout<<"Value is:"<<data_array.back()<<endl;

    //fill()

    data_array.fill(60);

    cout<<"After used fill() the value in an array are:";
    for(int i=0; i<5; i++)
        cout<<data_array[i]<<"  ";

    cout<<endl;

    //swap()

    data_array.swap(data_array1);

    cout<<"Array-1:";
    for(int i=0; i<5; i++)
        cout<<data_array[i]<<"  ";

    cout<<endl;

    cout<<"Array-2:";
    for(int i=0; i<5; i++)
        cout<<data_array1[i]<<"  ";

    cout<<endl;

    //size()

    cout<<"Size of the Array is:"<<data_array.size()<<endl;
    cout<<"Size of the Array is:"<<data_array1.size()<<endl;

    return 0;
}
