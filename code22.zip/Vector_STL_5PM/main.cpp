#include <iostream>
#include <vector>

using namespace std;

int main()
{
    //It supports dynamic array.
    //Array size if fixed, no flexibility to grow or shrink during execution.
    //Vector can provide memory flexibility.

    vector <int> v1; // only for declare of vector

    cout<<"Current Capacity is:"<<v1.capacity();

    vector <string> v2{"Garima", "Tanya", "C++", "Brain"};

    cout<<"Current Capacity is:"<<v2.capacity();

    return 0;
}
