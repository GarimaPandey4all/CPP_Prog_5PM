#include <iostream>

using namespace std;

class Student
{
private:
    string name;
    int age;

public:

    void setStudent(string s, int a)
    {
        name = s;
        age = a;
    }

    void showStudent()
    {
        cout<<"Name of the Student is:"<<name<<endl;
        cout<<"Age of the Student is:"<<age<<endl;
    }
};

int main()
{
    Student obj;
    obj.setStudent("Brain", 24);

    pair <string, int> p1;
    pair <string, string> p2;
    pair <string, float> p3;
    pair <int, Student> p4;

    //Insert values in a pair

    p1 = make_pair("Tanya", 24);
    p2 = make_pair("Brain", "Mentors");
    p3 = make_pair("Tanya", 45.78f);
    p4 = make_pair(25, obj);

    //Accessing values from the pair

    cout<<"Pair 1:"<<p1.first<<" "<<p1.second<<endl;
    cout<<"Pair 2"<<p2.first<<" "<<p2.second<<endl;
    cout<<"Pair 3:"<<p3.first<<" "<<p3.second<<endl;
    cout<<"Pair 4:"<<p4.first<<endl;

    Student obj1 = p4.second;

    obj1.showStudent();

    //Also apply relational operators

    if(p1.first != p2.first)
        cout<<endl<<"P1 is not equal to p2"<<endl;

    return 0;
}
