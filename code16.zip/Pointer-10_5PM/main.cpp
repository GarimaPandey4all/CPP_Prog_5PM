#include <iostream>

using namespace std;

int main()
{
    int value = 10;
    int number = 20;

    int *const pvalue = &value; // constant pointer // address can't be changed

    *pvalue = 20;

    //pvalue = &number; // error

    cout<<"Value is:"<<*pvalue;

    return 0;
}
