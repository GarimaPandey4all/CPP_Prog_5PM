#include <iostream>

using namespace std;

int main()
{
    int arr[5];

    cout<<"Enter 5 values in an array:";
    for(int i=0; i<5; i++)
    {
        cin>>*(arr + i);
    }

    cout<<"Values in an array are:";
    for(int i=0; i<5; i++)
    {
        cout<<*(arr + i)<<endl;
    }

    return 0;
}
