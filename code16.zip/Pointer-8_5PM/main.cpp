#include <iostream>

using namespace std;

int main()
{
    int value = 0;
    int *pvalue = &value;

    *pvalue = 56; // Dereferencing

    cout<<"Value is:"<<*pvalue;

    return 0;
}
