#include <iostream>

using namespace std;

int main()
{
    //Pointer to a constant

    int value = 10;
    int number = 20;

    const int *pvalue = NULL; // Pointer to a constant // value can't be changed

    pvalue = &value;

    //*pvalue = 20; // error

    pvalue = &number;

    cout<<"Value is:"<<*pvalue;

    return 0;
}
