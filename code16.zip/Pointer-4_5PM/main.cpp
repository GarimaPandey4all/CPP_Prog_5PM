#include <iostream>

using namespace std;

int main()
{
    int value = 100;

    int *pvalue = NULL;

    int result = 0;

    pvalue = &value;

    result = *pvalue + 30;

    cout<<"Result is:"<<result<<endl;

    *pvalue += 10;

    cout<<"Value is:"<<value<<endl;

    return 0;
}
