#include <iostream>

using namespace std;

int main()
{
    int value = 0;
    int *pvalue = NULL;

    pvalue = &value;

    cout<<"Enter any value:";
    cin>>*pvalue;

    cout<<"Value is:"<<*pvalue<<endl;

    return 0;
}
