#include <iostream>

using namespace std;

int main()
{
    int i = 10;
    float j = 2.3f;
    char z = 'A';

    void *ptr; // void pointer

    ptr = &i;
    cout<<"I is:"<<*(int *)ptr<<endl;

    ptr = &j;
    cout<<"J is:"<<*(float *)ptr<<endl;

    ptr = &z;
    cout<<"Z is:"<<*(char *)ptr<<endl;

    return 0;
}
