#include <iostream>

using namespace std;

int main()
{
    long num1 = 0L;
    long num2 = 0L;

    long *pnum = NULL;

    pnum = &num1; // num1 = 0
    *pnum = 2L; // num1 = 2L
    ++num2; // num2 = 1
    num2 += *pnum; // num2 = num2 + 2= 3

    pnum = &num2; // num2 = 3
    ++*pnum; // num2 = 4

    cout<<"Num1 is:"<<num1<<" Num2 is:"<<num2<<" *pnum is:"<<*pnum<<" *pnum + num2 is:"<<*pnum + num2;

    return 0;
}
