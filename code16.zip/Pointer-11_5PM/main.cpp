#include <iostream>

using namespace std;

int main()
{
    const int value = 10;
    int number = 20;

    const int *const pvalue = &value;
    // pointer to a constant and constant pointer // value and address can't be changed

    // *pvalue = 20; // error

    // pvalue = &number; // error

    // value = 20; // error

    cout<<"Value is:"<<*pvalue;

    return 0;
}
