#include <iostream>
#include <fstream>

using namespace std;

int main(int argc, char *agrv[])
{
    ifstream infile("Test.txt", ios::in);

    infile.seekg(22, ios::beg);

    int position = infile.tellg();

    cout<<"Current position of get pointer is:"<<position<<endl;

    //Read the next 14 characters from the file into a buffer

    char A[22];
    infile.read(A, 14);

    A[14] = 0; //End the buffer with null character

    cout<<"Content from the file is:"<<A<<endl;

    infile.close();

    return 0;
}
