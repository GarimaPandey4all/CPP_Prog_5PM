#include <iostream>
#include <fstream>

using namespace std;

int main()
{
    ofstream outfile("Test.txt", ios::out | ios::app);

    outfile<<"This is Write mode example in file handling.";

    cout<<"Current position of pointer is:"<<outfile.tellp();

    return 0;
}
