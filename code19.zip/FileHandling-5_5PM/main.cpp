#include <iostream>
#include <fstream>

using namespace std;

int main()
{
    ofstream outfile("Test.txt", ios::trunc);

    outfile<<"Welcome to Brain Mentors";

    outfile.close();

    return 0;
}
