#include <iostream>
#include <fstream>

using namespace std;

/*
    tellp() : tell current position of put pointer in write mode
*/

int main()
{

    ofstream outfile("Test.txt", ios::out);

    if(!outfile)
    {
        cout<<"Opening file error";
        exit(0);
    }

    outfile<<"This is an example of tellp().";

    cout<<"The current position of put pointer is:"<<outfile.tellp()<<endl;

    outfile.close();

}
