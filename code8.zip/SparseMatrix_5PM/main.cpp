#include <iostream>
#define N 5

using namespace std;

int main()
{
    int matrix1[N][N], i, j, rows, columns, total = 0;

    cout<<"Enter any number of rows:";
    cin>>rows;

    cout<<"Enter any number of columns:";
    cin>>columns;

    cout<<"Enter any values in Matrix-1:";
    for(i=0; i<rows; i++) //Loop for row
    {
        for(j=0; j<columns; j++) // Loop for Column
        {
            cin>>matrix1[i][j];
        }
    }

    cout<<"Values in Matrix-1 are:\n";
    for(i=0; i<rows; i++) //Loop for row
    {
        for(j=0; j<columns; j++) // Loop for Column
        {
            cout<<matrix1[i][j]<<"\t";
        }
        cout<<endl;
    }

    for(i=0; i<rows; i++) //Loop for row
    {
        for(j=0; j<columns; j++) // Loop for Column
        {
            if(matrix1[i][j] == 0)
                total++;
        }
    }

    if(total > (rows*columns)/2)
        cout<<"Sparse Matrix";
    else
        cout<<"Not a Sparse Matrix";

    return 0;
}
