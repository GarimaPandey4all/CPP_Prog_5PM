#include <iostream>
#define N 5

using namespace std;

int main()
{
    int matrix1[N][N], matrix2[N][N], result[N][N], i, j, rows, columns;

    cout<<"Enter any number of rows:";
    cin>>rows;

    cout<<"Enter any number of columns:";
    cin>>columns;

    cout<<"Enter any values in Matrix-1:";
    for(i=0; i<rows; i++) //Loop for row
    {
        for(j=0; j<columns; j++) // Loop for Column
        {
            cin>>matrix1[i][j];
        }
    }

    cout<<"Enter any values in Matrix-2:";
    for(i=0; i<rows; i++) //Loop for row
    {
        for(j=0; j<columns; j++) // Loop for Column
        {
            cin>>matrix2[i][j];
        }
    }

    cout<<"Values in Matrix-1 are:\n";
    for(i=0; i<rows; i++) //Loop for row
    {
        for(j=0; j<columns; j++) // Loop for Column
        {
            cout<<matrix1[i][j]<<"\t";
        }
        cout<<endl;
    }

    cout<<"Values in Matrix-2 are:\n";
    for(i=0; i<rows; i++) //Loop for row
    {
        for(j=0; j<columns; j++) // Loop for Column
        {
            cout<<matrix2[i][j]<<"\t";
        }
        cout<<endl;
    }

    //Addition
    for(i=0; i<rows; i++) //Loop for row
    {
        for(j=0; j<columns; j++) // Loop for Column
        {
            result[i][j] = matrix1[i][j] + matrix2[i][j];
        }
    }

    cout<<"Addition is:\n";
    for(i=0; i<rows; i++) //Loop for row
    {
        for(j=0; j<columns; j++) // Loop for Column
        {
            cout<<result[i][j]<<"\t";
        }
        cout<<endl;
    }

    return 0;
}
