#include <iostream>
#define N 5

using namespace std;

int main()
{
    int matrix1[N][N], temp[N][N], i, j, rows, columns, count = 0;

    cout<<"Enter any number of rows:";
    cin>>rows;

    cout<<"Enter any number of columns:";
    cin>>columns;

    cout<<"Enter any values in Matrix-1:";
    for(i=0; i<rows; i++) //Loop for row
    {
        for(j=0; j<columns; j++) // Loop for Column
        {
            cin>>matrix1[i][j];
        }
    }

    cout<<"Values in Matrix-1 are:\n";
    for(i=0; i<rows; i++) //Loop for row
    {
        for(j=0; j<columns; j++) // Loop for Column
        {
            cout<<matrix1[i][j]<<"\t";
        }
        cout<<endl;
    }

    //Logic of Transpose Matrix
    for(i=0; i<rows; i++) //Loop for row
    {
        for(j=0; j<columns; j++) // Loop for Column
        {
            temp[j][i] = matrix1[i][j];
        }
    }

    cout<<"Values in Transpose Matrix:\n";
    for(i=0; i<rows; i++) //Loop for row
    {
        for(j=0; j<columns; j++) // Loop for Column
        {
            cout<<temp[i][j]<<"\t";
        }
        cout<<endl;
    }

    for(i=0; i<rows; i++) //Loop for row
    {
        for(j=0; j<columns; j++) // Loop for Column
        {
            if(matrix1[i][j] != temp[i][j])
            {
                count++;
                break;
            }
        }
    }

    if(count == 0)
        cout<<"Symmteric Matrix";
    else
        cout<<"Not a Symmetric Matrix";

    return 0;
}
