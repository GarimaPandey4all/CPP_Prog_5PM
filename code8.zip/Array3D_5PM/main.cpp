#include <iostream>

using namespace std;

int main()
{
    int arr[2][2][2], i, j, k;

    cout<<"Enter any values 3D-Array:";
    for(i=0; i<2; i++) //Loop for row
    {
        for(j=0; j<2; j++) // Loop for Column
        {
            for(k=0; k<2; k++)
            cin>>arr[i][j][k];
        }
    }

    cout<<"Values in 3D-Array are:\n";
    for(i=0; i<2; i++) //Loop for row
    {
        for(j=0; j<2; j++) // Loop for Column
        {
            for(k=0; k<2; k++)
            cout<<arr[i][j][k]<<"\t";
        }
    }

    return 0;
}
