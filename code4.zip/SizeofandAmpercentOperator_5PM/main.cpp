#include <iostream>

using namespace std;

int main()
{
    //Size of Operator

    int a = 30;

    cout<<"SizeOF int:"<<sizeof(int)<<endl;
    cout<<"SizeOF char:"<<sizeof(char)<<endl;
    cout<<"SizeOF float:"<<sizeof(float)<<endl;
    cout<<"SizeOF double:"<<sizeof(double)<<endl;
    cout<<"SizeOF a:"<<sizeof(a)<<endl;

    //&

    cout<<"Address of a:"<<(&a);

    return 0;
}
