#include <iostream>

using namespace std;

int main()
{
    int a = 5, b = 4;

    cout<<"Bitwise And Operator:"<<(a&b)<<endl;
    cout<<"Bitwise OR Operator:"<<(a|b)<<endl;
    cout<<"Bitwise Not Operator:"<<(~a)<<endl;
    cout<<"Bitwise X-OR Operator:"<<(a^b)<<endl;
    cout<<"Bitwise Left Shift Operator:"<<(a<<3)<<endl;
    cout<<"Bitwise Right Shift Operator:"<<(b>>3)<<endl;

    return 0;
}
