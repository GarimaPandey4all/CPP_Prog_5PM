#include <iostream>

using namespace std;

int main()
{
    int sum = 10;
    int a = 50;

    sum += a; // sum = sum + a;

    cout<<"Sum is:"<<sum;

    return 0;
}
