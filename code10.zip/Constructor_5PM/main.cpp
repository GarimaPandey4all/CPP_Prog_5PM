#include <iostream>

using namespace std;

class Myclass
{
public:
    //constructor: must class name and constructor name both are same
    //When object created, constructor called automatically.
    Myclass()
    {
        cout<<"I'm Constructor"<<endl;
    }
};

int main()
{
    Myclass obj1;
    Myclass obj2;
    Myclass obj3;
    Myclass obj4;
    Myclass obj;

    return 0;
}
