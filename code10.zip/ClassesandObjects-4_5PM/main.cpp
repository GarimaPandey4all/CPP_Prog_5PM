#include <iostream>

using namespace std;

//DRY: Don't Repeat Yourself
class Calculator
{
public:
    int a, b;

    void add();
    void sub();
    void mul();
    void div();
};

void Calculator :: add()
{
    cout<<"Addition is:"<<endl;
    cout<<"Enter any value for a and b:";
    cin>>a>>b;

    cout<<a+b<<endl<<endl;
}

void Calculator :: sub()
{
    cout<<"Subtraction is:"<<endl;
    cout<<"Enter any value for a and b:";
    cin>>a>>b;

    cout<<a-b<<endl<<endl;
}

void Calculator :: mul()
{
    cout<<"Multiplication is:"<<endl;
    cout<<"Enter any value for a and b:";
    cin>>a>>b;

    cout<<a*b<<endl<<endl;
}

void Calculator :: div()
{
    cout<<"Division is:"<<endl;
    cout<<"Enter any value for a and b:";
    cin>>a>>b;

    cout<<a/b<<endl<<endl;
}

int main()
{
    Calculator obj;

    obj.add();
    obj.sub();
    obj.mul();
    obj.div();

    return 0;
}
