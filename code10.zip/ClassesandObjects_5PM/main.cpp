#include <iostream>

using namespace std;

class HelloWorld
{
public: //Access Specifier

    //Member Function
    void ShowData()
    {
        cout<<"Hello World";
    }

};

int main()
{
    HelloWorld obj;

    obj.ShowData(); //function calling of class

    return 0;
}
