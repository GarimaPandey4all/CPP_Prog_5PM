#include <iostream>

using namespace std;

/*
    Access Specifiers:

    1. Public
    2. Private
    3. Protected

*/

class varAssign
{
    int y;
public:
    int x;
};

int main()
{
    varAssign obj;

    obj.x = 10;

    //obj.y = 20; // error

    cout<<"x is:"<<obj.x<<endl;
    //cout<<"y is:"<<obj.y<<endl;

    return 0;
}
