#include <iostream>

using namespace std;

/*
    1. Function Definition inside the class
    2. Function Definition outside the class
*/

class HelloWorld
{
public:
    void showData(); // Only Declare the function
};

//return_type class_name :: function_name()

void HelloWorld :: showData()
{
    cout<<"Hello World";
}

int main()
{
    HelloWorld obj;
    obj.showData();

    return 0;
}
