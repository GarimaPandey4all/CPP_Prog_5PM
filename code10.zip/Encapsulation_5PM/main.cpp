#include <iostream>

using namespace std;

class Encapsulation
{
public:
    int x;

    void display()
    {
        cout<<"x is:"<<x<<endl;
    }
};

int main()
{
    Encapsulation obj;

    obj.x = 10;

    obj.display();

    return 0;
}
