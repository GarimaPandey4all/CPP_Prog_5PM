#include <iostream>

using namespace std;

class Car
{
public:
    string Brand;
    string Model;
    int Year;

    //Parameterized Constructor
    Car(string x, string y, int z)
    {
        //class variable = instance variable
        Brand = x;
        Model = y;
        Year = z;
    }
};

int main()
{
    Car obj("Maruti Suzuki", "C5", 2019);
    Car obj2("Honda", "H3", 2020);

    cout<<"Object -1:"<<endl;
    cout<<"Brand is:"<<obj.Brand<<endl;
    cout<<"Brand is:"<<obj.Model<<endl;
    cout<<"Brand is:"<<obj.Year<<endl<<endl<<endl;
    cout<<"Object -2:"<<endl;
    cout<<"Brand is:"<<obj2.Brand<<endl;
    cout<<"Brand is:"<<obj2.Model<<endl;
    cout<<"Brand is:"<<obj2.Year<<endl;

    return 0;
}
