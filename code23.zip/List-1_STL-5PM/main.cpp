#include <iostream>
#include <list>

using namespace std;

int main()
{
    list <int> l1; // only create a list

    list <string> l2 {"Mumbai", "Kathmandu"};

    list <int> l3 {10, 20, 30, 40, 50, 60, 70, 80, 90, 100};

    return 0;
}
