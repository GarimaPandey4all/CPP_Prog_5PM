#include <iostream>
#include <list>

using namespace std;

int main()
{
    list <string> l1{"New Delhi", "Chandigarh", "Mumbai"};

    //cout<<l1[0]; // error

    //iterator used to access the values from the list

    list <string> :: iterator itr = l1.begin();

    while(itr != l1.end())
    {
        cout<<*itr<<"  ";
        ++itr;
    }

    cout<<"\nTotal values in list are:"<<l1.size();

    return 0;
}
