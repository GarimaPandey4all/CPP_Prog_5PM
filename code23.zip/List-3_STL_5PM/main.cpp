#include <iostream>
#include <list>

using namespace std;

int main()
{
    list <string> l1{"New Delhi", "Chandigarh", "Mumbai"};

    l1.push_back("Kerala");

    l1.push_front("Jammu");

    list <string> :: iterator itr = l1.begin();

    while(itr != l1.end())
    {
        cout<<*itr<<"  ";
        ++itr;
    }

    cout<<"\nTotal values in list are:"<<l1.size();

    return 0;
}
