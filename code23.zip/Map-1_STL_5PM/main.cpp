#include <iostream>
#include <map>

using namespace std;

int main()
{
    map <int,string> customer; //Only create a map

    customer[100] = "Tanya";
    customer[145] = "Rahul";
    customer[235] = "Brain";
    customer[101] = "Dilip";

    //Or Second Way

    map <int, string> c2 {{100, "Tanya"}, {145, "Rahul"}, {235, "Brain"}, {101, "dilip"}};

    return 0;
}
