#include <iostream>
#include <list>

using namespace std;

int main()
{
    list <int> l1{50, 80, 10, 30, 60};

    list <int> :: iterator itr = l1.begin();

    while(itr != l1.end())
    {
        cout<<*itr<<"  ";
        ++itr;
    }

    cout<<"\nSize of list is:"<<l1.size()<<endl;

    l1.clear();

    cout<<"\nSize of list is:"<<l1.size()<<endl;

    return 0;
}
