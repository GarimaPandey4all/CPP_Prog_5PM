#include <iostream>
#include <list>

using namespace std;

int main()
{
    list <int> l1{50, 80, 10, 30, 60};

    list <int> :: iterator itr = l1.begin();

    while(itr != l1.end())
    {
        cout<<*itr<<"  ";
        ++itr;
    }

    cout<<"\nSize of list is:"<<l1.size()<<endl;

    l1.reverse();

    list <int> :: iterator itr1 = l1.begin();

    while(itr1 != l1.end())
    {
        cout<<*itr1<<"  ";
        ++itr1;
    }

    return 0;
}
