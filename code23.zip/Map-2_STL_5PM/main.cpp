#include <iostream>
#include <map>

using namespace std;

int main()
{
    map <int,string> customer; //Only create a map

    customer[100] = "Tanya";
    customer[145] = "Rahul";
    customer[235] = "Brain";
    customer[101] = "Dilip";

    //Or Second Way

    map <int, string> c2 {{100, "Tanya"}, {145, "Rahul"}, {235, "Brain"}, {101, "dilip"}};

    //Accessing values from the map: First Way

    cout<<"Customer 1:"<<customer[100]<<endl;
    cout<<"Customer 2:"<<customer[145]<<endl;
    cout<<"Customer 3:"<<customer[235]<<endl;
    cout<<"Customer 4:"<<customer[101]<<endl;

    //at()

    cout<<customer.at(145)<<endl;

    //Accessing values from the map: Second Way

    map <int, string> :: iterator itr = c2.begin();

    while(itr != c2.end())
    {
        cout<<itr->first<<endl;
        cout<<itr->second<<endl;

        ++itr;
    }

    cout<<"Total number of elements:"<<c2.size()<<endl;

    //empty(): It is used to check that array is empty or not.
    cout<<"Empty is:"<<c2.empty()<<endl;

    return 0;
}
