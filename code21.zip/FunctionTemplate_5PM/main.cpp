#include <iostream>

using namespace std;

//function Template
template <class T>
T Add(T a, T b)
{
    cout<<a+b<<endl;
}

int main()
{
    cout<<"Addition of Integers:"<<endl;
    Add(10, 20);
    cout<<endl;

    cout<<"Addition of Float:"<<endl;
    Add(14.35f, 20.78f);
    cout<<endl;

    cout<<"Addition of Double:"<<endl;
    Add(16.67, 20.90);
    cout<<endl;

    return 0;
}
