#include <iostream>

using namespace std;

template <class T>
class Calculator
{
private:
    T a, b;

public:
    void setData(T x, T y)
    {
        a = x;
        b = y;
    }

    void showData()
    {
        cout<<"Addition is:"<<a+b<<endl;
        cout<<"Subtraction is:"<<a-b<<endl;
        cout<<"Multiplication is:"<<a*b<<endl;
        cout<<"Division is:"<<a/b<<endl<<endl<<endl;
    }
};

int main()
{
    Calculator<int> obj1;
    obj1.setData(10, 20);


    Calculator<float> obj2;
    obj2.setData(34.67f,67.89f);


    Calculator<double> obj3;
    obj3.setData(12.3, 20.89);

    obj1.showData();
    obj2.showData();
    obj3.showData();

    return 0;
}
