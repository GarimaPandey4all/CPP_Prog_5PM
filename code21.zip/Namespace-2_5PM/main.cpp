#include <iostream>

using namespace std;

namespace dataType
{
    int value = 200;

    void showData()
    {
        cout<<"Hello World"<<endl;
    }
}

namespace dataType1
{
    int value = 300;

    void showData()
    {
        cout<<"Hello World"<<endl;
    }
}

int main()
{
    int value = 100;

    cout<<"Value is:"<<value<<endl;

    cout<<"Value is:"<<dataType::value<<endl;

    cout<<"Value is:"<<dataType1::value<<endl;

    dataType::showData();

    dataType1::showData();

    return 0;
}
