#include <iostream>

using namespace std;

template <class T>
class MaxNumber
{
private:
    T a, b;

public:
    void setData(T x, T y)
    {
        a = x;
        b = y;
    }

    void showData()
    {
        if(a > b)
            cout<<"A is Greater"<<endl;
        else
            cout<<"B is Greater"<<endl<<endl;
    }
};

int main()
{
    MaxNumber<int> obj1;
    obj1.setData(10, 20);


    MaxNumber<float> obj2;
    obj2.setData(34.67f,67.89f);


    MaxNumber<double> obj3;
    obj3.setData(12.3, 20.89);

    obj1.showData();
    obj2.showData();
    obj3.showData();

    return 0;
}
