#include <iostream>

using namespace std;

//function Template
template <class T>
T Swap(T a, T b)
{
    T temp = a;
    a = b;
    b = temp;

    cout<<"a is="<<a<<" b is="<<b<<endl;
}

int main()
{
    cout<<"Swapping of Integers:"<<endl;
    Swap(10, 20);
    cout<<endl;

    cout<<"Swapping of Float:"<<endl;
    Swap(14.35f, 20.78f);
    cout<<endl;

    cout<<"Swapping of Double:"<<endl;
    Swap(16.67, 20.90);
    cout<<endl;

    return 0;
}
