#include <iostream>

using namespace std;

namespace first
{
    int value = 500;
}

//Global Variable:
int value = 500;

int main()
{
    //local variable
    int value = 100;

    cout<<"Value is:"<<value<<endl;

    cout<<"Value is:"<<first::value<<endl;

    //std::cout << "Hello world!" << std::endl;
    return 0;
}
