#include <iostream>
#include <string.h>

using namespace std;

int main()
{
    char firstName[10];
    char lastName[10];

    cout<<"Enter your firstname:";
    gets(firstName);

    cout<<"Enter your lastname:";
    gets(lastName);

    cout<<"Your FullName is"<<strcat(firstName, lastName)<<endl;

    return 0;
}
