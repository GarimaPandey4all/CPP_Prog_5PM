#include <iostream>
#include <string.h>

using namespace std;

/*
    String Prebuild Functions:

    1. String Length
    2. String Copy
    3. String Concatenation/Joining
    4. String Compare
    5. String Lowercase/Uppercase

*/

int main()
{
    //Character of arrays : String
    char name[10];

    cout<<"Enter your name:";
    cin>>name;

    cout<<"Length of the string is:"<<strlen(name)<<endl;

    cout<<"String in Lowercase:"<<strlwr(name)<<endl;

    cout<<"String in Uppercase:"<<strupr(name)<<endl;


    return 0;
}
