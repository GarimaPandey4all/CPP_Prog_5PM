#include <iostream>

using namespace std;

//Exceptions: Abnormal Behaviour : runtime errors


int main()
{
    cout<<"Exception Handling"<<endl;

    //double value = 10.2;

    int value = 23;

    try{
        if(value == 10.2)
            throw 10.2;
        if(value == 23)
            throw 23;
        if(value == 'A')
            throw 'A';

        cout<<"Try Block"<<endl;
    }

    catch(int e)
    {
        cout<<"Exception is:"<<e<<endl;
    }

    catch(double e)
    {
        cout<<"Exception is:"<<e<<endl;
    }

    catch(char e)
    {
        cout<<"Exception is:"<<e<<endl;
    }

    cout<<"Outside the try-catch block.";

    return 0;
}
