#include <iostream>

using namespace std;

void MyFunc()
{
    throw 10;
}

int main()
{
    try{
        MyFunc(); // Function calling

        cout<<"Try Block"<<endl;
    }

    catch(...)
    {
        cout<<"Exception here.";
    }

    return 0;
}
