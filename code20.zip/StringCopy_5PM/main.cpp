#include <iostream>
#include <string.h>

using namespace std;

int main()
{
    char str1[10];
    char str2[10];

    cout<<"Enter any city name:";
    //cin>>str1;

    gets(str1); // get string // read user input

    cout<<"String 1 copying in String 2:"<<strcpy(str2, str1)<<endl;

    cout<<"String 1 copying in String 2:"<<strcpy(str2, "Pune")<<endl;

    cout<<str2<<endl;

    return 0;
}
