#include <iostream>
#include <string.h>

using namespace std;

/*
    String Compare: strcmp(a, b);

    a > b = 1

    b > a = -1

    a == a = 0

*/

int main()
{
    char str1[10];
    char str2[10];

    cout<<"Enter string-1:";
    gets(str1);

    cout<<"Enter string-2:";
    gets(str2);

    if(strcmp(str1, str2) == 0)
        cout<<"You Entered the same strings";
    else
        cout<<"Not the Same strings";

    return 0;
}
