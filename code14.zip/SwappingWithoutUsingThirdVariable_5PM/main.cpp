#include <iostream>

using namespace std;

int main()
{
    int a, b;

    cout<<"Enter any value for a and b:";
    cin>>a>>b;

    cout<<"Before Swapping the value of a="<<a<<" and b="<<b<<"."<<endl;;

    //First Way: + and - Operators

    //a = 5, b = 4
//    a = a + b; // a = 9
//    b = a - b; // 9 - 4 = 5, b = 5
//    a = a - b; // 9 - 5 = 4, a = 4

    //Second Way: * and / Operators

//    a = a * b; // a = 20
//    b = a / b; // 20/4 = 5
//    a = a / b; // 20/5 = 4

    //Third Way: X-OR Operator

    a = a ^ b;
    b = a ^ b;
    a = a ^ b;

    cout<<"After Swapping the value of a="<<a<<" and b="<<b<<"."<<endl;

    return 0;
}
