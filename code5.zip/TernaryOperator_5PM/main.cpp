#include <iostream>

using namespace std;

int main()
{
    int a, b, c;

    cout<<"Enter value for a, b, and c:";
    cin>>a>>b>>c;

    int largest = (a>b) ? ((a>c)? a : c) : ((b>c)? b : c);

    cout<<"Largest number is:"<<largest;

    return 0;
}
