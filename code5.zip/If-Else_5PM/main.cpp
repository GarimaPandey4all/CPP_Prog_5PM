#include <iostream>

using namespace std;

int main()
{
    int number;

    cout<<"Enter any number:";
    cin>>number;

    //isEven - isOdd

    int remainder = number % 2;

    if(remainder == 0)
        cout<<"Number is Even.";
    else
        cout<<"Number is Odd.";

    return 0;
}
