#include <iostream>

using namespace std;

int main()
{
    int n = 100;

    if(n == 100)
    {
        if(100%2 == 0)
            cout<<"Number is Even";
        else
            cout<<"Number is Odd";
    }
    else{
        cout<<"n is not equal to 100.";
    }

    return 0;
}
