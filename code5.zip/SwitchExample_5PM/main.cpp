#include <iostream>

using namespace std;

int main()
{
    char choice;
    int a, b;

    cout<<"Enter any operator:";
    cin>>choice;

    //Switch: Menu Driven Program
    switch(choice)
    {
    case '+':
        cout<<"Enter any value for a and b:";
        cin>>a>>b;
        cout<<"Addition is:"<<a+b;
        break;

    case '-':
        cout<<"Enter any value for a and b:";
        cin>>a>>b;
        cout<<"Subtraction is:"<<a-b;
        break;

    case '*':
        cout<<"Enter any value for a and b:";
        cin>>a>>b;
        cout<<"Multiplication is:"<<a*b;
        break;

    case '/':
        cout<<"Enter any value for a and b:";
        cin>>a>>b;
        cout<<"Division is:"<<a/b;
        break;

    default:
        cout<<"Invalid Choice.";

    }

    return 0;
}
