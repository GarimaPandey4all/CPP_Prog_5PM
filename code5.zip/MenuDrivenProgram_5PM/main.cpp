#include <iostream>

using namespace std;

int main()
{
    int choice;
    int a, b, c;
    int largest;
    int number;

    /*
        Infinite Loop
        while(1)
        for(;;)
    */

    while(1)
    {

    cout<<"\n\nPress 1. Even-Odd.\n";
    cout<<"Press 2. Largest Number.\n";
    cout<<"Press 3. Bitwise XOR.\n";
    cout<<"Press 4. Exit.\n";

    cout<<"\n\nEnter your choice:";
    cin>>choice;

    switch(choice)
    {
    case 1:

        cout<<"Enter any number:";
        cin>>number;

        (number % 2 == 0) ? cout<<"Number is Even" : cout<<"Number is Odd";

        break;

    case 2:

        cout<<"Enter value for a, b, and c:";
        cin>>a>>b>>c;

        largest = (a>b) ? ((a>c)? a : c) : ((b>c)? b : c);

        cout<<"Largest number is:"<<largest;

        break;

    case 3:

        cout<<"Enter any value for a and b:";
        cin>>a>>b;

        cout<<"X-OR is:"<<(a^b);

        break;

    case 4:
        exit(0);

     default:
        cout<<"Invalid Choice:";

    }
    }

    return 0;
}
