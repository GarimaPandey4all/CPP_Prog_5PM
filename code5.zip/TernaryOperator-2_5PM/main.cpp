#include <iostream>

using namespace std;

int main()
{
    int number;

    cout<<"Enter any number:";
    cin>>number;

    (number % 2 == 0) ? cout<<"Number is Even" : cout<<"Number is Odd";

    return 0;
}
