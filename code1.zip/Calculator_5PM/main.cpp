#include <iostream>

using namespace std;

//-->Single Line

/*
    Multiple Line

    Name: Brain Mentors
    Date: 17-07-2020
    Time: 6:22 PM

    Program : Calculator
*/

int main()
{
    int a, b; // declaration

    cout<<"Enter any value for a and b:";
    cin>>a>>b;

    cout<<"Addition is:"<<a+b<<endl;
    cout<<"Subtraction is:"<<a-b<<endl;
    cout<<"Multiplication is:"<<a*b<<endl;
    cout<<"Division is:"<<a/b<<endl;

    return 0;
}
