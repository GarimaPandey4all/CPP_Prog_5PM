#include <iostream>

using namespace std;

int main()
{
    int i, sum = 0;
    int arr[5];

    cout<<"Enter any values in an array:";
    for(i=0; i<5; i++)
    {
        cin>>arr[i];
    }

    for(i=0; i<5; i++)
    {
        sum += arr[i]; //sum = sum + arr[i];
    }

    cout<<"Sum of the array is:"<<sum;

    return 0;
}
