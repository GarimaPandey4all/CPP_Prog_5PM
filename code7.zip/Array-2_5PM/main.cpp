#include <iostream>
#define MONTHS 12

using namespace std;

int main()
{
    int days[MONTHS] = {31, 29, 30, 31, 30, 31, 30, 31, 30, 30, 31, 31};

    for(int i=0; i<MONTHS; i++)
    {
        cout<<"Month "<<i+1<<" has "<<days[i]<<" days."<<endl;
    }

    return 0;
}
