#include <iostream>

using namespace std;

int main()
{
    int arr[5]; //Array Declare

    //Traditional way of declaration and initialization
    int arr1[5] = {10, 20, 30, 40, 50}; // Array Declare and Initialize

    //Access the value from the array
    cout<<arr1[0]<<endl;
    cout<<arr1[1]<<endl;
    cout<<arr1[2]<<endl;
    cout<<arr1[3]<<endl;
    cout<<arr1[4]<<endl;

    //Compile Time Declaration/Initialization
    int arr2[] = {10, 20, 30, 40, 50, 60, 70};

    //Multidimentional Array

    int arr3[2][3] = {1, 2, 3, 4, 5, 6};

    int arr4[][3] = {{1, 2, 3},
                     {4, 5, 6},
                     {7, 8, 9}};

    int arr5[2][3][4];

    return 0;
}
