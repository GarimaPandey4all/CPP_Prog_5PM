#include <iostream>
#define N 5

using namespace std;

int main()
{
    int matrix1[N][N], int matrix2[N][N], int result[N][N], i, j, rows, columns;

    cout<<"Enter any number of rows:";
    cin>>rows;

    return 0;
}
