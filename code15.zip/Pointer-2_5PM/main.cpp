#include <iostream>

using namespace std;

int main()
{
    int value = 100;

    int *pvalue = &value;

    cout<<"Value is:"<<*pvalue<<endl;

    *pvalue = 200;

    cout<<"Value is:"<<*pvalue<<endl;

    cout<<"Value is:"<<value<<endl;

    return 0;
}
