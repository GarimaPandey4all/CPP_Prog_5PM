#include <iostream>

using namespace std;

int main()
{
    int Count = 10, x;

    int *pcount = NULL;

    pcount = &Count;

    x = *pcount;

    cout<<"X is:"<<x<<endl;

    cout<<"Count is:"<<*pcount<<endl;

    return 0;
}
