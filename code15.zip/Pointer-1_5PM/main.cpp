#include <iostream>

using namespace std;

int main()
{
    int value = 10;

    int *pvalue = NULL;

    pvalue = &value;

    cout<<"Value is:"<<*pvalue<<endl;

    cout<<"Value is:"<<pvalue<<endl;

    cout<<"Value of Pvalue is:"<<&pvalue<<endl;

    return 0;
}
