#include <iostream>

using namespace std;

/*
    New Line
    \n - C
    endl - C++
*/

int main()
{
    int i = 1; //declaration for do-while loop
    int n;

    cout<<"Enter any number:";
    cin>>n;

    do
    {
        //block of do-while loop
        cout<<n<<" * "<<i<<" = "<<n*i<<endl;
        i++;

    }while(i<=10); //condition

    return 0;
}
