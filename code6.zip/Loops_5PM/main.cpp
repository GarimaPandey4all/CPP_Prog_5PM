#include <iostream>

using namespace std;

/*
    Loops means Iteration/Repetition

    Loops Types:

    1. For Loop
    2. While Loop
    3. Do-While Loop

*/

int main()
{
    int i;

//    for(initialization; condition; increment/decrement)
//    {
//        //block of loop
//    }

    for(i=1; i<=10; i++)
    {
        cout<<"Counter-"<<i<<endl;
    }

    return 0;
}
