#include <iostream>

using namespace std;

//Function Declaration
/*return_type function_name(); // optional*/

//Function Definition
/*return type function_name()
{

}
*/

void HelloWorld()
{
    cout<<"Hello World"<<endl;
}

int main()
{
    //function calling
    //function_name();
    HelloWorld();
    HelloWorld();
    HelloWorld();
    HelloWorld();
    HelloWorld();
    HelloWorld();
    HelloWorld();

    return 0;
}
