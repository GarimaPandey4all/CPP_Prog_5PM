#include <iostream>

using namespace std;

//3. With function parameter and without return type
//Function Declaration
void Add(int , int);

//Function Prototype
void Add(int a, int b) // a, b: Function Parameters/Formal Parameters
{
    cout<<"Addition is:"<<a+b<<endl;
}

int main()
{
    Add(20, 40); // 20, 40: Function Arguments/Actual Parameters

    return 0;
}
