#include <iostream>

using namespace std;

//4. With function parameter and with return type
//Function Declaration
int Add(int , int);

//Function Prototype
int Add(int a, int b) // a, b: Function Parameters/Formal Parameters
{
    return a+b;
}

int main()
{
    int sum = Add(20, 40); // 20, 40: Function Arguments/Actual Parameters

    cout<<"Addition is:"<<sum<<endl;

    return 0;
}
