#include <iostream>

using namespace std;

//1. Without function parameter and without return type

void Add()
{
    int a, b;

    cout<<"Enter any value for a and b:";
    cin>>a>>b;

    cout<<"Addition is:"<<a+b<<endl;

}

int main()
{
    Add();
    Add();
    Add();
    Add();

    return 0;
}
