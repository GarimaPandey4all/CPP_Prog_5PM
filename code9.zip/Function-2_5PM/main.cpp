#include <iostream>

using namespace std;

//2. Without function parameter and with return type

int Add()
{
    int a, b;

    cout<<"Enter any value for a and b:";
    cin>>a>>b;

    cout<<"Addition is:"<<a+b<<endl;

    //return a+b;

    return 0;
}

int main()
{
    Add();
//    int sum = Add();
//
//    cout<<"Addition is:"<<sum<<endl;

    return 0;
}
