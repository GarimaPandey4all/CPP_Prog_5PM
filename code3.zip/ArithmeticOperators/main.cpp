#include <iostream>

using namespace std;

int main()
{
    int a, b;

    cout<<"Enter any value for a and b:";
    cin>>a>>b;

    //Arithmetic Operators

    cout<<"Addition is:"<<a+b<<endl;

    cout<<"Subtraction is:"<<a-b<<endl;

    cout<<"Multiplication is:"<<a*b<<endl;

    cout<<"Division is:"<<a/b<<endl;

    //Modulus --> remainder
    cout<<"Modulus is:"<<a%b<<endl; // a = 5, b = 4, 5 % 4 = 1

    //Increment Operator
    //Pre and Post Increment

    cout<<"Pre-Increment is:"<<++a<<endl; // a = 5, a = 5+1 = 6

    cout<<"Post-Increment is:"<<a++<<endl; // a = 6, a = 6

    cout<<"a is:"<<a<<endl; //a = 7

    //Decrement Operator
    //Pre and Post Decrement

    cout<<"Pre-Decrement is:"<<--b<<endl; // b= 4, b = 4 - 1 = 3

    cout<<"Post-Decrement is:"<<b--<<endl; // b = 3, b = 3

    cout<<"b is:"<<b<<endl; // b = 2

    return 0;
}
