#include <iostream>
#include <fstream>

using namespace std;

int main()
{
    //Writing in a file

    ofstream outfile("Test.txt", ios::out);

    //outfile.open("Test.txt", ios::out);

    outfile<<"Tanya"<<endl;
    outfile<<"Swati"<<endl;
    outfile<<"Welcome to Brain Mentors"<<endl;

    outfile.close();

    return 0;
}
