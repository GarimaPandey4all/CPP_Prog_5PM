#include <iostream>

using namespace std;

/*
    int main(int argc, char *argv[])
    {


    }

    1. Argument Count
    2. Argument Vector : Character of Pointer

    main(5, (program_name, Tanya, 10, 19, Amit))
*/

int main(int argc, char *argv[])
{
    int i;

    for(i=0; i<argc; i++)
    {
        cout<<"Arguments are:"<<argv[i]<<endl;
    }

    cout<<"Argument count is:"<<argc<<endl;

    return 0;
}
