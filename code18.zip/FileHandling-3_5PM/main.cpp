#include <iostream>
#include <fstream>

using namespace std;

int main()
{
    //Reading from the file

    char ch;

    ifstream infile("Test.txt", ios::in);

    while(infile)
    {
        infile.get(ch);
        cout<<ch;
    }

    infile.close();

    return 0;
}
