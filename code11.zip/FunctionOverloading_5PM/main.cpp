#include <iostream>

using namespace std;

class func_Overloading
{
public:

    void func(int a)
    {
        cout<<"a is:"<<a<<endl;
    }

    void func(int x, int y)
    {
        cout<<"x is:"<<x<<endl;
        cout<<"y is:"<<y<<endl;
    }

    void func(float z)
    {
        cout<<"z is:"<<z<<endl;
    }

};

int main()
{
    func_Overloading obj;

    obj.func(10);
    //obj.func(); // error
    obj.func(10, 20);
    obj.func(50.6f);

    return 0;
}
