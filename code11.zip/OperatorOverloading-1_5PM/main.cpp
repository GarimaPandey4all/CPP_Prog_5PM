#include <iostream>

using namespace std;

class Complex
{
private:
    int real;
    int imag;

public:
    Complex(int r, int i)
    {
        real = r;
        imag = i;
    }
};

int main()
{
    Complex obj1(4, 7);
    Complex obj2(2, 3);

    //error
//    Complex obj3;
//
//    obj3 = obj1 + obj2; // obj1.add(obj2);

    return 0;
}
