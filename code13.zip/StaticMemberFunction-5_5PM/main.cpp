#include <iostream>

using namespace std;

class Demo
{
public:
    static void func()
    {
        cout<<"This is static member function block."<<endl;
    }
};

int main()
{
    Demo :: func(); // Calling static member function directly with class name

    return 0;
}
