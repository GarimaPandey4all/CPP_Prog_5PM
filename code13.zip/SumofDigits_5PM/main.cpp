#include <iostream>

using namespace std;

int main()
{
    int n, sum = 0, r;

    cout<<"Enter any number:";
    cin>>n;

    while(n > 0)
    {
        r = n % 10; // 123 = 6: 3, 2, 1
        sum = sum + r; // 0 + 3, 5, 6
        n = n / 10; // 123 = 12, 1, 0
    }

    cout<<"Sum of Digits is:"<<sum<<endl;

    return 0;
}
