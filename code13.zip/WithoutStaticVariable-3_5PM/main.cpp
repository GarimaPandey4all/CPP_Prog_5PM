#include <iostream>

using namespace std;

class Counter
{
public:
    void updateCount()
    {
        int Count = 0; //Static int Count = 0;
        cout<<Count++<<" ";
    }
};

int main()
{
    Counter obj;
    for(int i=0; i<5; i++)
        obj.updateCount();

    return 0;
}
