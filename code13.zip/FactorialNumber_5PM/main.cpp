#include <iostream>

using namespace std;

int main()
{
    int n, fact = 1, i;

    cout<<"Enter any number to check factorial:";
    cin>>n;

    for(i=1; i<=n; i++)
        fact *= i;

    cout<<"Factorial number of "<<n<<"! is:"<<fact<<endl;

    return 0;
}
