#include <iostream>

using namespace std;

class Student
{
private:
    int rollno; //instance variable
    static int marks; // static variable / class member variable

public:

    void  setData(int r)
    {
        rollno = r;
    }

    void getData()
    {
        cout<<"Roll no is:"<<rollno<<endl;
        cout<<"Marks is:"<<marks<<endl;
    }
};

// data_type Class_name :: static_variable = value;
int Student :: marks = 548;

int main()
{
    Student obj;
    obj.setData(11);
    obj.getData();

    return 0;
}
