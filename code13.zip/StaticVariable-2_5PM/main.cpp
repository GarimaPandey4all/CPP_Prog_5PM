#include <iostream>

using namespace std;

//Static Variable inside function

class Counter
{
public:
    void updateCount()
    {
        static int Count; //Static int Count = 0;
        cout<<Count++<<" ";
    }
};

int main()
{
    Counter obj;
    for(int i=0; i<5; i++)
        obj.updateCount();

    return 0;
}
