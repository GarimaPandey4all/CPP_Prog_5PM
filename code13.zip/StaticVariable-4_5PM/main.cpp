#include <iostream>

using namespace std;

class Employee
{
public:
    static int age;

    Employee()
    {
        cout<<"Age is:"<<age<<endl; //First way
    }
};

int Employee :: age = 25;

int main()
{
    Employee obj;

    cout<<"Age is:"<<obj.age<<endl; // Second Way

    return 0;
}
