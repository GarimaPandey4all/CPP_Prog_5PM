#include <iostream>

using namespace std;

int main()
{
    int n, sum = 0, r, temp;

    cout<<"Enter number to check whether the number is palindrome or not:";
    cin>>n;

    temp = n;

    while(n > 0)
    {
        r = n % 10;
        sum = sum * 10 + r;
        n = n / 10;
    }

    n = temp;

    (n == sum) ? cout<<"Palindrome Number" : cout<<"Not a Palindrome Number";

    return 0;
}
