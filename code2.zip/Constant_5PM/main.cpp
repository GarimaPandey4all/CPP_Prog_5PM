#include <iostream>

using namespace std;

int main()
{
    const int num = 50;

    //num = 70; //error

    cout<<"Num is:"<<num;

    return 0;
}
