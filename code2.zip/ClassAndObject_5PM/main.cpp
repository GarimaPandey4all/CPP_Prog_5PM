#include <iostream>

using namespace std;

class sum
{
public: //Access Specifier
    int a, b;

    void add()
    {
//        cout<<"Enter value for a and b:";
//        cin>>a>>b;
        cout<<"Addition of two numbers is:"<<a+b;
    }
};

int main()
{
    sum obj;
    obj.a = 10;
    obj.b = 20;
    obj.add();

    return 0;
}
