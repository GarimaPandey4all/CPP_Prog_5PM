#include <iostream>

using namespace std;

int main()
{
    int a = 10;

    a = 50;

    cout<<"A is:"<<a<<endl;

    a = 90;

    cout<<"A is:"<<a;

    return 0;
}
