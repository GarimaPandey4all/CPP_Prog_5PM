#include <iostream>
#define NUM 50 //Macros --> value fixed

using namespace std;

int main()
{
    //NUM = 60; //error

    cout<<"Num is:"<<NUM;

    return 0;
}
