#include <iostream>

using namespace std;

struct Date
{
    int Day;
    int Month;
    int Year;
}date;

//struct Date date1, date2, date3;

int main()
{
    //struct Date date1;

    date.Day = 6;
    date.Month = 8;
    date.Year = 2020;

    cout<<"Day is:"<<date.Day<<" Month is:"<<date.Month<<" Year is:"<<date.Year<<endl;

    return 0;
}
