#include <iostream>

using namespace std;

//Enum : Enumeration : Group of constants

int main()
{
    enum Week {Monday = 1, Tuesday, Wednesday, Thursday, Friday, Saturday, Sunday};

    enum Week Today = Monday;

    cout<<"Today is:"<<Today<<endl;

    return 0;
}
