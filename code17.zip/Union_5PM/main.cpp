#include <iostream>

using namespace std;

union Date
{
    int Day;
    int Month;
    int Year;
}date;

//union Date date1, date2, date3;

int main()
{
    //union Date date1;

    date.Day = 6;
    cout<<"Day is:"<<date.Day<<endl;

    date.Month = 8;
    cout<<"Month is:"<<date.Month<<endl;

    date.Year = 2020;
    cout<<"Year is:"<<date.Year<<endl;

    return 0;
}
