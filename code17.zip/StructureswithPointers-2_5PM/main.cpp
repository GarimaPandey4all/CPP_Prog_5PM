#include <iostream>

using namespace std;

struct Date
{
    int Day;
    int Month;
    int Year;
}date, *pdate;

//struct Date date1, date2, date3;

int main()
{
    //struct Date date1;

    pdate = &date;

    pdate->Day = 6;
    pdate->Month = 8;
    pdate->Year = 2020;

    cout<<"Day is:"<<(*pdate).Day<<" Month is:"<<(*pdate).Month<<" Year is:"<<(*pdate).Year<<endl;

    return 0;
}
