#include <iostream>

using namespace std;

void swap(int *a, int *b)
{
    int temp = *a;
    *a = *b;
    *b = temp;
}

int main()
{
    int a, b;

    cout<<"Enter any value for a and b:";
    cin>>a>>b;

    cout<<"Before Swapping the value for a and b is:"<<a<<" "<<b<<endl<<endl;

    swap(&a, &b);

    cout<<"After Swapping the value for a and b is:"<<a<<" "<<b<<endl;

    return 0;
}
